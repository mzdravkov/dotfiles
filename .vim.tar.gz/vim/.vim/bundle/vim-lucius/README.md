vim-lucius
==========

This repository has the Lucius color scheme for Vim. It is already organized
under a "colors" directory, so you can clone the repo into your own vimfiles
(or under bundle, if you use Pathogen).

The color scheme is available for other applications, as well. They can be
found here:

https://github.com/jonathanfilip/lucius


