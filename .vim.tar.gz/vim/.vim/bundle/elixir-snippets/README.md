# Snipmate snippets for [Elixir](http://elixir-lang.org)

## Install
* copy the files to your `~/.vim`
* if you use vim-pathogen drop the files into `~/.vim/bundle`
